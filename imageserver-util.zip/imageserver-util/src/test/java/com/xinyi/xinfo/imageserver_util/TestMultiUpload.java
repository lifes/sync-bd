/**
 *	Copyright © 1997 - 2015 Xinyi Tech. All Rights Reserved 
 */
package com.xinyi.xinfo.imageserver_util;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.IdentityHashMap;

import org.apache.http.client.ClientProtocolException;

import com.xinyi.xinfo.imageserver_util.commons.utils.Constant;
import com.xinyi.xinfo.imageserver_util.commons.utils.HttpHelper;
import com.xinyi.xinfo.imageserver_util.commons.utils.IdentityHashMapOperate;
import com.xinyi.xinfo.imageserver_util.commons.utils.ResponseContent;

 
/**
 * 功能说明：测试文件批量上传功能
 * 
 * TestMultiUpload.java
 * 
 * Original Author: liangliang.jia,2015年9月16日下午4:52:44
 * 
 * Copyright (C)1997-2015 深圳信义科技 All rights reserved.
 */
public class TestMultiUpload {

	public static void main(String[] args) throws ClientProtocolException, IOException {
		testUploadMultiFiles();
	}

	/**
	 * 新的多文件删除方式，推荐使用此方法,(组装Map时，使用IdentityMap,可以重复key) 编写了新方法，对Map进行排序处理
	 * 批量上传，为了便于理解，没有写成循环方式。
	 */
	public static void testUploadMultiFiles() {
		try {
			//String url = "http://10.235.156.102:8070/uploadBulk";
			 //String url = "http://10.235.156.138:8070/uploadBulk";
			String url = "http://10.235.156.146:8070/uploadBulk";
			IdentityHashMap<String, Object> paramsMap = new IdentityHashMap<String, Object>();
			// 相同的key内容(由于是new出来的，内存地址不同但内容相同)，但value不会被覆盖
			//图片一信息
			File file1 = new File("D:\\temp\\55.jpg");
			IdentityHashMap<String, Object> map = new IdentityHashMap<String, Object>();
			try {
				FileInputStream fin1 = new FileInputStream(file1);
				byte[] data1 = new byte[fin1.available()];
				fin1.read(data1);
				fin1.close();
				map.put(Constant.IMAGESERVER_UPLOAD_FILENAME, "55.jpg");
				map.put(Constant.IMAGESERVER_UPLOAD_FILE, data1);
				paramsMap = IdentityHashMapOperate.addValue(paramsMap, IdentityHashMapOperate.zimu[0], map);
			} catch (Exception e) {
				e.printStackTrace();
			}
			//图片二信息
			File file2 = new File("D:\\temp\\11.jpg");
			try {
				FileInputStream fin2 = new FileInputStream(file2);
				byte[] data2 = new byte[fin2.available()];
				fin2.read(data2);
				fin2.close();
				
				IdentityHashMap<String, Object> map1 = new IdentityHashMap<String, Object>();
				map1.put(Constant.IMAGESERVER_UPLOAD_FILENAME, "11.jpg");
				map1.put(Constant.IMAGESERVER_UPLOAD_FILE, data2);
				paramsMap = IdentityHashMapOperate.addValue(paramsMap, IdentityHashMapOperate.zimu[1], map1);

			} catch (Exception e) {
				e.printStackTrace();
			}
		
			//图片二信息
			File file3 = new File("D:\\temp\\22.jpg");
			try {
				FileInputStream fin3 = new FileInputStream(file3);
				byte[]  data3 = new byte[fin3.available()];
				fin3.read(data3);
				fin3.close();
				
				IdentityHashMap<String, Object> map2 = new IdentityHashMap<String, Object>();
				map2.put(Constant.IMAGESERVER_UPLOAD_FILENAME, "22.jpg");
				map2.put(Constant.IMAGESERVER_UPLOAD_FILE, data3);
				paramsMap = IdentityHashMapOperate.addValue(paramsMap, IdentityHashMapOperate.zimu[2], map2);
			} catch (Exception e) {
				e.printStackTrace();
			}
	 
			paramsMap.put(Constant.IMAGESERVER_UPLOAD_ACCESSUSER, "XINYI");
			paramsMap.put(Constant.IMAGESERVER_UPLOAD_ACCESSKEY, "1A9AD595-B415-4529-A41C-4E5C2071430C");
			paramsMap.put(Constant.IMAGESERVER_UPLOAD_STORENAME, "VEHICLE");
			paramsMap.put(Constant.IMAGESERVER_UPLOAD_TYPENAME, "gaoqing"); 
			paramsMap.put(Constant.IMAGESERVER_UPLOAD_FILETYPE, "IMAGE");
			
			 
			//一次批量上传数据不易超过50M ，图片不超过100张
			ResponseContent ret = HttpHelper.postEntityList(url, paramsMap);
			System.out.println(ret.getContent());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	 
}
