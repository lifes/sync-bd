/**
 *	Copyright © 1997 - 2015 Xinyi Tech. All Rights Reserved 
 */
package com.xinyi.xinfo.imageserver_util;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.IdentityHashMap;
import java.util.Map;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.mime.MultipartEntity;
import org.apache.http.entity.mime.content.FileBody;
import org.apache.http.entity.mime.content.StringBody;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;

import com.xinyi.xinfo.imageserver_util.commons.utils.Constant;
import com.xinyi.xinfo.imageserver_util.commons.utils.HttpHelper;
import com.xinyi.xinfo.imageserver_util.commons.utils.ResponseContent;
 

/**
 * 功能说明：
 * 
 * SingleFileUpload.java
 * 
 * Original Author: liangliang.jia,2015年9月16日下午5:38:56
 * 
 * Copyright (C)1997-2015 深圳信义科技 All rights reserved.
 */
public class SingleFileUpload {

	public static void main(String[] args) throws ClientProtocolException, IOException {
	 
		testUploadSingleFile();
	}
	
	/**
	 * 对Http Client 进行封装，方便用户调用，推荐使用该方式
	 */
	public static void testUploadSingleFile() {
		try {
			
				String url = "http://10.235.156.146:8072/uploadSingle";
			    //String url = "http://10.235.156.138:8070/uploadSingle";
			//String url = "http://10.235.156.146:8072/uploadSingle";
				Map<String, Object> paramsMap = new IdentityHashMap<String, Object>();

				File file = new File("D:/temp/1.jpg");
				try {
					FileInputStream fin = new FileInputStream(file);
					byte[] data = new byte[fin.available()];
					fin.read(data);
					fin.close();
					
					
					paramsMap.put(Constant.IMAGESERVER_UPLOAD_ACCESSUSER, "XINYI");
					paramsMap.put(Constant.IMAGESERVER_UPLOAD_ACCESSKEY, "1A9AD595-B415-4529-A41C-4E5C2071430C");
					paramsMap.put(Constant.IMAGESERVER_UPLOAD_STORENAME, "VEHICLE");
					paramsMap.put(Constant.IMAGESERVER_UPLOAD_TYPENAME, "gaoqing"); 
					paramsMap.put(Constant.IMAGESERVER_UPLOAD_FILETYPE, "IMAGE");
					paramsMap.put(Constant.IMAGESERVER_UPLOAD_FILENAME, "0_1.jpg");
					paramsMap.put(Constant.IMAGESERVER_UPLOAD_FILE, data);
	 
				
				} catch (Exception e) {
					e.printStackTrace();
				}
				//通过HTTP方式进行图片上传
				ResponseContent ret = HttpHelper.postEntity(url, paramsMap);
				System.out.println(ret.getContent());
			
			
			//打印返回如：http://172.16.1.8:8090/images/2015/11/12/001010-20151112121410-001.jpg
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
