//单个上传和批量上传图片，调用方法测试如下
public class testUploadImage {
	public static void main(String[] args) {
		
		testMultiImagesUpload();
	}
	
	/**
	 * 对Http Client 进行封装，方便用户调用
	 */
	 //打印返回如：http://172.16.1.8:8090/images/2015/11/12/001010-20151112121410-001.jpg
	public static void testSingleImageUpload(){
		String postUrl = "http://localhost:8070/upload/post";

		File file = new File("D:\\temp\\001010-20151112121410-001.jpg");
		
		String fileName = "001010-20151112121410-001.jpg";
		String resultStr = FileUploadUtil.uploadSingleImage(postUrl, file, fileName);
		
		System.out.println("The result is :" + resultStr);
	}
	
	/**
	 * 新的多文件删除方式，推荐使用此方法,(组装Map时，使用IdentityMap,可以重复key) 编写了新方法，对Map进行排序处理
	 * 批量上传，一次批量上传数据不易超过50M ，图片不超过50张
	 */
	 //打印结果如：
	//http://172.16.1.10:8090/images/2015/11/12/001010-20151112121410-001.jpg;http://172.16.1.10:8090/images/2015/11/12/001010-20151112121410-002.jpg
		
	public static void testMultiImagesUpload(){
		String postUrl = "http://localhost:8070/upload/tpost";
		
		IdentityHashMap<String, Object> paramsMap = new IdentityHashMap<String, Object>();
		// 相同的key内容(由于是new出来的，内存地址不同但内容相同)，但value不会被覆盖
		//图片一信息
		File[] files = new File[2];
		files[0] = new File("D:\\temp\\001010-20151112121410-001.jpg");
		files[1] = new File("D:\\temp\\001010-20151112121410-002.jpg");
		String[] fileNames = new String[]{"001010-20151112121410-001.jpg","001010-20151112121410-002.jpg"};
		String resultStr = FileUploadUtil.uploadMultiImage(postUrl, files, fileNames);
		
		System.out.println("The result is :" + resultStr);
	}
}

需要依赖的jar包如下：
  <properties>
    <project.build.sourceEncoding>UTF-8</project.build.sourceEncoding>
    <httpcomponents.version>4.3.4</httpcomponents.version>
  </properties>

  <dependencies>
   	<dependency>
			<groupId>org.apache.httpcomponents</groupId>
			<artifactId>httpclient</artifactId>
			<version>${httpcomponents.version}</version>
	</dependency>

	<dependency>
			<groupId>org.apache.httpcomponents</groupId>
			<artifactId>httpmime</artifactId>
			<version>${httpcomponents.version}</version>
	</dependency>
  </dependencies>
