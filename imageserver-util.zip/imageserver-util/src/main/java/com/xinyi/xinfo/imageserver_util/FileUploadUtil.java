package com.xinyi.xinfo.imageserver_util;

import java.io.File;
import java.io.FileInputStream;
import java.util.IdentityHashMap;
import java.util.Map;

import com.xinyi.xinfo.imageserver_util.commons.utils.Constant;
import com.xinyi.xinfo.imageserver_util.commons.utils.HttpHelper;
import com.xinyi.xinfo.imageserver_util.commons.utils.IdentityHashMapOperate;
import com.xinyi.xinfo.imageserver_util.commons.utils.ResponseContent;

/**
 * 功能说明：
 * 
 * FileUploadUtil.java
 * 
 * Original Author: Administrator,2015年12月3日下午4:05:44
 * 
 * Copyright (C)1997-2015 深圳信义科技 All rights reserved.
 */
public class FileUploadUtil {
	/**
	 * 对Http Client 进行封装，方便用户调用，推荐使用该方式
	 */
	public static String uploadSingleImage(String postUrl,File file,String fileName) {
		String resultStr = null;
		try {
			String url = postUrl;
			Map<String, Object> paramsMap = new IdentityHashMap<String, Object>();
			
			try {
				FileInputStream fin = new FileInputStream(file);
				byte[] data = new byte[fin.available()];
				fin.read(data);
				fin.close();
				//提交图片信息
				paramsMap.put(new String(Constant.IMAGESERVER_UPLOAD_FILENAME), fileName);
				paramsMap.put(new String(Constant.IMAGESERVER_UPLOAD_FILE), data);
			} catch (Exception e) {
				e.printStackTrace();
			}
			//通过HTTP方式进行图片上传
			ResponseContent ret = HttpHelper.postEntity(url, paramsMap);
			resultStr = ret.getContent();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return resultStr;
	}
	
	/**
	 * 新的多文件删除方式，推荐使用此方法,(组装Map时，使用IdentityMap,可以重复key) 编写了新方法，对Map进行排序处理
	 * 批量上传，为了便于理解，没有写成循环方式。
	 */
	public static String uploadMultiImage(String postUrl,File[] file,String[] fileName ) {
		String resultStr = null;
		try {
			String url = postUrl;
			if(file != null && file.length > 0){
				IdentityHashMap<String, Object> paramsMap = new IdentityHashMap<String, Object>();
				for(int i=0;i< file.length; i++){
					// 相同的key内容(由于是new出来的，内存地址不同但内容相同)，但value不会被覆盖
					IdentityHashMap<String, Object> map = new IdentityHashMap<String, Object>();
					try {
						FileInputStream fin = new FileInputStream(file[i]);
						byte[] data = new byte[fin.available()];
						fin.read(data);
						fin.close();
						//
						map.put(Constant.IMAGESERVER_UPLOAD_FILENAME, fileName[i]);
						map.put(Constant.IMAGESERVER_UPLOAD_FILE, data);
						paramsMap = IdentityHashMapOperate.addValue(paramsMap, IdentityHashMapOperate.zimu[i], map);
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
				//一次批量上传数据不易超过50M ，图片不超过100张
				ResponseContent ret = HttpHelper.postEntityList(url, paramsMap);
				resultStr = ret.getContent();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return resultStr;
	}
}
