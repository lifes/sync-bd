/**
*	Copyright © 1997 - 2015 Xinyi Tech. All Rights Reserved 
*/
package com.xinyi.xinfo.imageserver_util.start;

import java.io.File;
import java.util.logging.Logger;

import com.xinyi.xinfo.imageserver_util.FileUploadUtil;

/**
 * 功能说明：
 * 
 * ApplicationStart.java
 * 
 * Original Author: Administrator,2015年12月28日上午11:42:51
 * 
 * Copyright (C)1997-2015 深圳信义科技 All rights reserved.
 */
public class ApplicationStart {
	public static void main(String[] args) {
		String postUrl = "http://10.42.22.229:8070/upload/post";

		File file = new File("D:\\temp\\11.jpg");
		
		String fileName = "11.jpg";
		String resultStr = FileUploadUtil.uploadSingleImage(postUrl, file, fileName);
		
		System.out.println("The result is :" + resultStr);
	}
}
