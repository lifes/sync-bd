/**
*	Copyright © 1997 - 2016 Xinyi Tech. All Rights Reserved 
*/
package com.xinyi.xinfo.imageserver_util.commons.utils;


/**
 * 功能说明：
 * 
 * Constant.java
 * 
 * Original Author: Administrator,2016年1月1日上午9:45:53
 * 
 * Copyright (C)1997-2016 深圳信义科技 All rights reserved.
 */
public class Constant {

	public static final String IMAGESERVER_UPLOAD_ACCESSUSER = "accessUser";
	
	public static final String IMAGESERVER_UPLOAD_ACCESSKEY = "accessKey";
	
	public static final String IMAGESERVER_UPLOAD_STORENAME = "storeName";
	
	public static final String IMAGESERVER_UPLOAD_TYPENAME = "typeName";
	
	public static final String IMAGESERVER_UPLOAD_FILETYPE = "fileType";
	
	public static final String IMAGESERVER_UPLOAD_FILE = "file";
	
	public static final String IMAGESERVER_UPLOAD_FILENAME = "fileName";
	
	public static final String IMAGESERVER_UPLOAD_STATUS_CODE = "statusCode";
	
	public static final String IMAGESERVER_UPLOAD_MESSAGE = "message";
	
	public static final int IMAGESERVER_UPLOAD_MESSAGE_SUCCESS =100;
	
	public static final int IMAGESERVER_UPLOAD_MESSAGE_ERROR =101;
	
	public static final int IMAGESERVER_UPLOAD_MESSAGE_AUTH_FAILURE =102;
	
	public static final int IMAGESERVER_UPLOAD_MESSAGE_ERROR_FORM =103;
}
 
